package com.upgrad.FoodOrderingApp.service.common;

public enum ItemType {

    VEG,NON_VEG;
}
