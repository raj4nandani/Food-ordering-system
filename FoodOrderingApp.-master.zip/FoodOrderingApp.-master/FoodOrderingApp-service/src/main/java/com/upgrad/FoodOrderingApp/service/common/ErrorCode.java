package com.upgrad.FoodOrderingApp.service.common;

public interface ErrorCode {

    String getCode();

    String getDefaultMessage();

}